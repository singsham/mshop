import React, { Component } from "react";
import axios from "axios";

import Upload from "./components/Upload";
import MediaList from "./components/MediaList";
import InfoModal from "./components/InfoModal";
import MediaPlay from './components/MediaPlay';

class App extends Component {
  state = {
    mediaFiles:[],
    selectedFile: null,
    processBar: false,
    showModal:false,
    modalContents:null,
    mediaUrl:'https://mshop-musicapp-bucket.s3.ap-south-1.amazonaws.com/Jonas-Brothers,-Demi-Lovato,-Miley-Cyrus,-Selena-Gomez---Send-It-On-Official-Music-Video---YouTube.flv',
    inputKey:Date.now()
  };

  componentWillMount() {
    axios.get("http://localhost:5000/api/media/media-list").then((response)=>{
      if(200 === response.status){
        this.setState({mediaFiles:response.data.mediaUrl})
        console.log(response.data.mediaUrl);
      }
    })
  }

  singleFileChangedHandler = (e) => {
    this.setState({
      selectedFile:e.target.files[0]
    });
  };

  singleFileUploadHandler = () => {
    const data = new FormData();
    this.setState({ processBar: true });
    // If file selected
    if (this.state.selectedFile) {
      data.append("profileImage", this.state.selectedFile, this.state.selectedFile.name.replace(/\s/g, "-"));

      axios
        .post("http://localhost:5000/api/media/media-upload", data, {
          headers: {
            accept: "application/json",
            "Accept-Language": "en-US,en;q=0.8",
            "Content-Type": `multipart/form-data; boundary=${data._boundary}`
          }
        })
        .then((response) => {
          this.setState({ processBar: false });
          if (200 === response.status) {
            // If file size is larger than expected.
            if (response.data.error) {
              this.setState({showModel:true,modalContents:response.data.error})
            }else {
            // Success
            const mediaData=response.data;
            this.setState({mediaFiles:[mediaData,...this.state.mediaFiles],selectedFile:null,showModal:true,modalContents:"File Uploaded",inputKey:Date.now()});
            console.log("fileName", this.state.mediaFiles);
          }}
        })
        .catch((error) => {
          // If another error
          this.setState({ processBar: false,showModal:true,modalContents:error,inputKey:Date.now()});
        });
    } else {
      // if file not selected throw error
      this.setState({ processBar: false,showModal:true,modalContents:"Please upload file" });
    }
  };

  hideModalHandler=()=>{
    this.setState({showModal:false});
  }

  mediaPlayhandler=(fileUrl)=>{
    this.setState({mediaUrl:fileUrl});
    console.log('inside handler',this.state.mediaUrl);
  }
  render() {
    return (
      <div>
        <div className="jumbotron jumbotron-fluid">
          <h1 className="display-3 text-center">mShop Music App</h1>
          <h3 className="display-5 text-right mr-5">just listen...anywhere</h3>
        </div>
        <InfoModal content={this.state.modalContents} showModal={this.state.showModal} hideModal={this.hideModalHandler}/>

        <div className="container">
          <div className="row">
            <Upload singleFileUploadHandler={this.singleFileUploadHandler} singleFileChangedHandler={this.singleFileChangedHandler} processBar={this.state.processBar} inputKey={this.state.inputKey}/>
            <MediaPlay mediaUrl={this.state.mediaUrl}/>
          </div>
          <div className="row">
            <h4 className="btn btn-info text-light" >Your Playlist</h4>
            <MediaList mediaFiles={this.state.mediaFiles} mediaPlayhandler={this.mediaPlayhandler}/>
          </div>
        </div>

        <div className="jumbotron">
          <h1 className="display-4 text-center">Powered by mShop</h1>
        </div>
      </div>
    );
  }
}

export default App;
