import React from "react";

const mediaPlay = (props) => (
  <div className="col-lg-7">
    <div className="card border-light mb-1 shadow p-3 mb-5 bg-white rounded">
      <video controls key={props.mediaUrl}>
        <source src={props.mediaUrl} />
      </video>
    </div>
  </div>
);

export default mediaPlay;
