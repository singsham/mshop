import React from "react";
import { Scrollbars } from "react-custom-scrollbars";

const mediaList = (props) => {
  if (props.mediaFiles == null) return null;
  const mediaLink = props.mediaFiles.map((files, index) => (
    <li className="list-group-item card border-light shadow p-3 mb-1 bg-white rounded" key={index} onClick={() => props.mediaPlayhandler(files.fileUrl)}>
      <h6>Title : {files.fileName}</h6>
    </li>
  ));

  return (
    <Scrollbars style={{ height: 500 }}>
      <ul className="col-lg-5 list-group">{mediaLink}</ul>
    </Scrollbars>
  );
};

export default mediaList;
