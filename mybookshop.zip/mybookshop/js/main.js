// sticky navigation

let navbar = $(".navbar");

$(window).scroll(() => {
  let oTop = $(".panel").offset().top - window.innerHeight;

  if ($(window).scrollTop() > oTop) {
    navbar.addClass("sticky");
  } else {
    navbar.removeClass("sticky");
  }
});

// Counter Animation

let nCount = function(selector) {
  $(selector).each(() => {
    console.log($(this).text());
    $(this)
      .prop("Counter", 0)
      .animate(
        {
          Counter: $(this).text()
        },
        {
          duration: 4000,
          easing: "swing",
          step: (now) => {
            console.log(now);
            $(this).text(Math.ceil(now));
          }
        }
      );
  });
};

let a = 0;

$(window).scroll(function() {
  const oTop = $(".numbers").offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() >= oTop) {
    nCount(".rect>h1");
    a++;
  }
});
