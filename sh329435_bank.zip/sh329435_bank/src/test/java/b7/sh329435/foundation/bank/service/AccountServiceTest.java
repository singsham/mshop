package b7.sh329435.foundation.bank.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.entity.Name;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@RunWith(MockitoJUnitRunner.class)
public class AccountServiceTest {

	@Mock
	private AccountRepository repo;

	@InjectMocks
	private AccountServiceImpl serviceImpl;

	@Test
	public void testRetriveAccountById() throws Exception {
		Account expectedAccount = new Account(1001L, new Customer(101L, new Name("rahul", "kumar")), "joint", 2431.43);
		doReturn(expectedAccount).when(repo).getOne(1001L);

		Account actualAccount = serviceImpl.retriveAccount(1001L);
		assertThat(actualAccount).isEqualTo(expectedAccount);
	}

	@Test
	public void testRetriveAllAccounts() throws Exception {
		List<Account> expectedAccounts = new ArrayList<Account>(
				Arrays.asList(new Account(1001L, new Customer(101L, new Name("rahul", "kumar")), "joint", 2431.43)));
		doReturn(expectedAccounts).when(repo).findAll();

		List<Account> actualAccounts = serviceImpl.retriveAllAccount();
		assertThat(actualAccounts).isEqualTo(expectedAccounts);
	}

	@Test
	public void testAddAccount() throws Exception {
		Account expectedAccount = new Account(1001L, new Customer(101L, new Name("nivi", "kumari")), "joint", 7872.232);
		doReturn(expectedAccount).when(repo).save(expectedAccount);

		Account actualAccount = serviceImpl.createAccount(expectedAccount);
		assertThat(actualAccount).isEqualTo(expectedAccount);
	}

}
