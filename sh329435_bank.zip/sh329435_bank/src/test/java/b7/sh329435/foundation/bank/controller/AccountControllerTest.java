package b7.sh329435.foundation.bank.controller;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.entity.Name;
import b7.sh329435.foundation.bank.service.AccountService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(AccountController.class)
public class AccountControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AccountService service;

	//@Test
	public void testHelloWorld() throws Exception {
		when(service.welcomeMessage()).thenReturn("Hello World");

		mockMvc.perform(get("/")).andDo(print()).andExpect(status().isOk()).andExpect(content().string("Hello World"));
	}

	//@Test
	public void testRetriveAccountById() throws Exception {
		Account testAccount1 = new Account(1001L,new Customer(101L,new Name("rahul", "kumar")), "joint", 2431.43);
		
		when(service.retriveAccount(1001L)).thenReturn(testAccount1);

		mockMvc.perform(get("/bank/accounts/{id}",1001)).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id", Matchers.is(1001)))
				.andExpect(jsonPath("$.*", Matchers.hasSize(4)));
	}

	//@Test
	public void testRetriveAllAccounts() throws Exception {
		List<Account> accounts = new ArrayList<Account>(Arrays.asList(new Account(1001L,new Customer(101L,new Name("rahul", "kumar")), "joint", 2431.43)));
		doReturn(accounts).when(service).retriveAllAccount();

		mockMvc.perform(get("/bank/accounts")).andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].customer.fullName.firstName").value("rahul"))
				.andExpect(jsonPath("$", Matchers.hasSize(1)));
	}
	
	@Test
	public void testAddAccount() throws Exception {
		Account testAccount = new Account(new Customer(new Name("nivi", "kumari")), "joint", 7872.232);
		when(service.createAccount(testAccount)).thenReturn(testAccount);

		mockMvc.perform(post("/bank/accounts").content(asJsonString(testAccount)).contentType(MediaType.APPLICATION_JSON_UTF8).accept(MediaType.APPLICATION_JSON_UTF8)).andDo(print())
				.andExpect(status().isOk()).andReturn();
				//.andExpect(jsonPath("$.id").value(1001))
				//.andExpect(jsonPath("$", Matchers.hasSize(4)));
	}

	public static String asJsonString(final Object obj) {
		try {
			System.out.println("###########"+new ObjectMapper().writeValueAsString(obj));
			return new ObjectMapper().writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}
}
