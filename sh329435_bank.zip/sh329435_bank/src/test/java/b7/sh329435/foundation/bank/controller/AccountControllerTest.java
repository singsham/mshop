package b7.sh329435.foundation.bank.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;




import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import b7.sh329435.foundation.bank.service.AccountService;


@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountControllerTest {

	private MockMvc mvc;

	@Mock
	private AccountService service;
	
	@InjectMocks
	private AccountController accountController;
	
	@Before
	public void setUp() throws Exception{
		mvc = MockMvcBuilders.standaloneSetup(accountController).build();
	}
	
	
	  @Test public void testHelloWorld() throws Exception {
	  //when(helloService.hello()).thenReturn("hello"); 
		mvc.perform(get("/"))
		  	.andExpect(status().isOk()) .andExpect(content().string("Hello Java"));
	  //verify(helloService).hello();
	  
	  }
	 

	@Test
	public void retriveAccountById() throws Exception {
		
		//when(service.retriveAccount(1020L)).thenReturn(acc);
		
		mvc.perform(get("/bank/accounts").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$",Matchers.hasSize(0)));
			//.andExpect(jsonPath("$[0].id", Matchers.is(1020)));
			//.andExpect(jsonPath("$.*",Matchers.hasSize(5)));
	}

}
