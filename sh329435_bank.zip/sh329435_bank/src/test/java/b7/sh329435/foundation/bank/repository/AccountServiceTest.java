package b7.sh329435.foundation.bank.repository;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.entity.Name;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountServiceTest {
	
	@Autowired
	private AccountRepository repository;
	
	@Test
	public void testCreateAccount() {
		Name name= new Name("shambu","singh");
		Customer cust= new Customer(name);
		Account account = repository.save(new Account(cust,"saving",2431.43));
				
		System.out.println("#######user inserted"+account);
		
		Iterable<Account> accounts = repository.findAll();
		assertThat(accounts).size().isEqualByComparingTo(1);
	}
	
	@Test
	public void testFindAll() {
		List<Account> accounts = repository.findAll();
		accounts.forEach(account->System.err.println("####Each Account"+account));
		assertThat(accounts).size().isEqualByComparingTo(2);
	}

}
