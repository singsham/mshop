package b7.sh329435.foundation.bank.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.entity.Name;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountRepoTest {

	@Autowired
	private AccountRepository repository;

	Account testAccount1 = new Account(new Customer(new Name("shambu", "singh")), "saving", 2431.43);
	Account testAccount2 = new Account(new Customer(new Name("rahul", "mukhija")), "current", 5431.93);

	/*
	 * @Before public void before() {
	 * System.out.println("this is called before all test case"); }
	 */
	
	@Test
	public void testFindAll() {
		List<Account> accounts = repository.findAll();
		assertThat(accounts).isEmpty();
	}

	@Test
	public void testCreateAccount() {
		repository.save(testAccount1);
		repository.save(testAccount2);

		Iterable<Account> accounts = repository.findAll();
		assertThat(accounts).size().isEqualByComparingTo(2);
	}

	@Test
	public void testDeleteById() {
		Account acc = repository.save(testAccount1);
		repository.save(testAccount2);

		List<Account> accountsBeforeDelete = repository.findAll();
		assertThat(accountsBeforeDelete).size().isEqualByComparingTo(2);
		
		repository.deleteById(acc.getId());
		List<Account> accountsAfterDelete = repository.findAll();
		assertThat(accountsAfterDelete).size().isEqualByComparingTo(1);
	}

	@Test
	public void testGetOne() {
		Account acc1 = repository.save(testAccount1);
		Account acc2 = repository.save(testAccount2);

		Optional<Account> fetchAccount = repository.findById(acc1.getId());
		assertThat(fetchAccount).contains(acc1);

	}

}
