package b7.sh329435.foundation.bank.repository;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.entity.Name;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountRepoTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private AccountRepository repository;

	private Account persist;
	private Account persist2;

	@Before
	public void setup() {
		this.persist = entityManager.persist(new Account(new Customer(new Name("ravi", "kosana")), "saving", 2431.43));
		this.persist2 = entityManager.persist(new Account(new Customer(new Name("shambu", "singh")), "current", 6431.93));
	}

	@Test
	public void testCreateAccount() {
		Account testAccount = new Account(new Customer(new Name("deepak", "sharma")), "current", 5431.93);
		repository.save(testAccount);

		Iterable<Account> accounts = repository.findAll();
		assertThat(accounts).size().isEqualByComparingTo(3);
	}

	@Test
	public void testFindAll() {
		List<Account> accounts = repository.findAll();
		assertThat(accounts).hasSize(2);
	}

	@Test
	public void testFindById() {
		Optional<Account> fetchAccounts = repository.findById(persist.getId());
		assertThat(fetchAccounts.get().getCustomer().getFullName().getFirstName()).isEqualTo("ravi");
	}

	@Test
	public void testDeleteById() {
		repository.deleteById(persist.getId());
		List<Account> accountsAfterDelete = repository.findAll();
		assertThat(accountsAfterDelete).size().isEqualByComparingTo(1);
	}

	@Test
	public void testDeleteAll() {
		List<Account> accountsBeforeDelete = repository.findAll();
		assertThat(accountsBeforeDelete).size().isEqualByComparingTo(2);

		repository.deleteAll();
		List<Account> accountsAfterDelete = repository.findAll();
		assertThat(accountsAfterDelete).size().isEqualByComparingTo(0);
	}

}
