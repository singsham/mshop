package b7.sh329435.foundation.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository repository;
	
	public List<Customer> retriveAllCustomer() {
		return repository.findAll();
	}

}
