package b7.sh329435.foundation.bank.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@SequenceGenerator(name = "account_seq", initialValue = 1001, allocationSize = 1)
public class Account implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_seq")
	private Long id;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cid")
	private Customer customer;

	private String accountType;

	private Double balance;

	public Account(Customer customer, String accountType, Double balance) {
		super();
		this.customer = customer;
		this.accountType = accountType;
		this.balance = balance;
	}

}
