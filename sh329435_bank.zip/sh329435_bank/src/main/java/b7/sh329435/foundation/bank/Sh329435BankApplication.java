package b7.sh329435.foundation.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sh329435BankApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sh329435BankApplication.class, args);
		System.out.println("hello spring########");
	}

}
