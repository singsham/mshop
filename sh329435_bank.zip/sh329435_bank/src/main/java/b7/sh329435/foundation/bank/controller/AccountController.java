package b7.sh329435.foundation.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.exception.AccountNotFoundException;
import b7.sh329435.foundation.bank.service.AccountService;
import b7.sh329435.foundation.bank.service.CustomerService;

@RestController
@RequestMapping("bank")
public class AccountController {
	
	@Autowired
	AccountService service;
	
	@GetMapping("/accounts")
	public List<Account> retriveAllAccount(){
		return service.retriveAllAccount();
	}
	
	@GetMapping("/accounts/{id}")
	public Account retriveAccount(@PathVariable Long id){
		return service.retriveAccount(id);
	}
	
	@PostMapping("/accounts")
	public Account createAccount(@RequestBody Account account) {
		return service.createAccount(account);
	}
	
	@DeleteMapping("/accounts/{id}")
	public Account removeAccount(@PathVariable Long id) {
		Account account = service.deleteById(id);
		if(account==null) {
			throw new AccountNotFoundException("User ID ="+id);
		}else {
			return account;
		}
	}
	
	@PutMapping("/accounts/{id}")
	public Account updateAccount(@RequestBody Account account,@PathVariable Long id) {
		return service.updateAaccount(id,account);
	}
	
	@PutMapping("/accounts/{fromId}/{toId}/{amount}")
	public String transferFunds(@PathVariable Long from,@PathVariable Long to,@PathVariable Double amount) {
		return service.transferFunds(from,to,amount);
	}
	
	
}
