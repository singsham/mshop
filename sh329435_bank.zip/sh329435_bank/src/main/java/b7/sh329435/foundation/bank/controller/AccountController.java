package b7.sh329435.foundation.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.service.AccountService;

@RestController
public class AccountController {
	
	@Autowired
	AccountService service;
	
	@GetMapping("/")
	public String welcomeMessage() {
		return "Hello Java";
		
	}
	
	@GetMapping("/bank/accounts")
	public List<Account> retriveAllAccount(){
		return service.retriveAllAccount();
	}
	
	@GetMapping("/bank/accounts/{id}")
	public Account retriveAccount(@PathVariable Long id){
		return service.retriveAccount(id);
	}
	
	@PostMapping("/bank/accounts")
	public Account createAccount(@RequestBody Account account) {
		return service.createAccount(account);
	}
	
	@DeleteMapping("/bank/accounts/{id}")
	public Account removeAccount(@PathVariable Long id) {
		return service.deleteById(id);
	}
	
	@PutMapping("/bank/accounts/{id}")
	public Account updateAccount(@RequestBody Account account,@PathVariable Long id) {
		return service.updateAaccount(id,account);
		
	}
	
	@PutMapping("/bank/accounts/{fromId}/{toId}/{amount}")
	public String transferFunds(@PathVariable Long fromId,@PathVariable Long toId,@PathVariable Double amount) {
		return service.transferFunds(fromId,toId,amount);
	}
	
	
}
