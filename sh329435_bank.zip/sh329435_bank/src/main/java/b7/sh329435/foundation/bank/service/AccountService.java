package b7.sh329435.foundation.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@Service
public interface AccountService {
	
	public String welcomeMessage();
	
	public List<Account> retriveAllAccount();

	public Account retriveAccount(Long id);

	public Account createAccount(Account account);

	public Account deleteById(Long id);

	public Account updateAaccount(Long id, Account account);

	public String transferFunds(Long from, Long to, Double amount);

}
