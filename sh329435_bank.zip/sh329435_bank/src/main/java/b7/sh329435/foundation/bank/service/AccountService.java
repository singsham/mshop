package b7.sh329435.foundation.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository repository;

	public List<Account> retriveAllAccount() {
		return repository.findAll();
	}

	public Account retriveAccount(Long id) {
		try {
			Account account = repository.getOne(id);
			return account;
		} catch (Exception e) {
			return null;
		}
	}

	public Account createAccount(Account account) {
		return repository.save(account);
	}

	public Account deleteById(Long id) {
		try {
			Account account = repository.getOne(id);
			repository.deleteById(id);
			return account;
		} catch (Exception e) {
			return null;
		}
	}

	public Account updateAaccount(Long id, Account account) {
		try {
			Account acc = repository.getOne(id);
			acc = repository.save(account);
			return acc;
		} catch (Exception e) {
			return null;
		}
	}

	public String transferFunds(Long from, Long to, Double amount) {
		try {
			Account fromAccount = repository.getOne(from);
			Account toAccount = repository.getOne(to);
			if (fromAccount.getBalance() < amount) {
				return "INSUFFICIENT FUNDS";
			} else {
				toAccount.setBalance(toAccount.getBalance() + amount);
				fromAccount.setBalance(fromAccount.getBalance() - amount);
				repository.save(toAccount);
				repository.save(fromAccount);
				return "SUCCESS";
			}
		} catch (Exception e) {
			return "ID MISMATCH";
		}
	}

}
