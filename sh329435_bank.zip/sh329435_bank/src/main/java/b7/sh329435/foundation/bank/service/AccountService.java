package b7.sh329435.foundation.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import b7.sh329435.foundation.bank.entity.Account;
import b7.sh329435.foundation.bank.repository.AccountRepository;

@Component
public class AccountService {
	
	@Autowired
	AccountRepository repository;
	
	public List<Account> retriveAllAccount() {
		return repository.findAll();
	}

	public Account createAccount(Account account) {
		return repository.save(account);
	}

	public Account retriveAccount(Long id) {
		return repository.getOne(id);
	}
	
	public Account deleteById(Long id) { 
		Account account = repository.getOne(id);
		if(account != null) {
			repository.deleteById(id);
			return account;
		}else{
			return null;
		}
	}

	public Account updateAaccount(Long id, Account account) {
		Account acc = repository.getOne(id);
		if(acc!=null) {
			acc = repository.save(account);
		}
		return acc;
	}

	public String transferFunds(Long from, Long to, Double amount) {
		Account fromAccount = repository.getOne(from);
		Account toAccount = repository.getOne(to);
		if(fromAccount == null || toAccount==null) {
			return "ID MISMATCH";
		}
		if(fromAccount.getBalance()<amount) {
			return "INSUFFICIENT FUNDS";
		}else { 
			toAccount.setBalance(toAccount.getBalance()+amount);
			repository.save(toAccount);
			return "SUCCESS";
		}
	}

}
