package b7.sh329435.foundation.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import b7.sh329435.foundation.bank.entity.Customer;
import b7.sh329435.foundation.bank.service.CustomerService;

@RestController
@RequestMapping("bank")
public class CustomerController {
	@Autowired
	CustomerService service;
	
	@GetMapping("/customers")
	public List<Customer> retriveAllCustomer(){
		return service.retriveAllCustomer();
	}
}
