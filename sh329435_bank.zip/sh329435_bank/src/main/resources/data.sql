INSERT INTO customer(cust_id, email, first_name, last_name) VALUES ('101', 'shambu.singh@gmail.com', 'shambu', 'singh');
INSERT INTO customer(cust_id, email, first_name, last_name) VALUES ('102', 'rahul.singh@gmail.com', 'rahul', 'mukhija');

INSERT INTO account_type(acc_type_id, acc_type_name) VALUES ('1', 'saving');
INSERT INTO account_type(acc_type_id, acc_type_name) VALUES ('2', 'current');
INSERT INTO account_type(acc_type_id, acc_type_name) VALUES ('3', 'joint');

INSERT INTO account(acc_id, acc_balance, acc_type_id, cust_id) VALUES ('1001', '3032', '1', '101');
INSERT INTO account(acc_id, acc_balance, acc_type_id, cust_id) VALUES ('1002', '531.24', '3', '102');