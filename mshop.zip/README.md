# A React Js and Node Js for access s3 Bucket
## Installation Instructions

Install nodemon and create-react-app globally using below command:

`$ npm i -D nodemon`

`npm i -g create-react-app`
