const express = require( 'express' );
const bodyParser = require( 'body-parser' );
const media = require( './route/api/media' );

const router = express.Router();
const app = express();

app.use( '/api/media', media );

app.use( bodyParser.urlencoded( { extended: false } ) );
app.use( bodyParser.json() );

// We export the router so that the server.js file can pick it up
module.exports = router;


app.listen( 5000, () => console.log( 'Server running on port 5000') );